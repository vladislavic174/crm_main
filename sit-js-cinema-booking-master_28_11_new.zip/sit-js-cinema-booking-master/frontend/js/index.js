function on_movie_select(event) {
    var selectedDate = event.target.value;
    // debugger;
    sessionStorage.setItem("selected_date", selectedDate);
    const movieList = document.getElementById("movie-list");
    // debugger;
    movieList.innerHTML = "";
    print_movies_list();
}

async function get_cinema_data()
{
    if (sessionStorage.getItem("cinema_data") == null | sessionStorage.getItem("cinema_data") == "undefined") {
        var cinema = await BackendAPI.getSchedule();
        sessionStorage.setItem("cinema_data", JSON.stringify(cinema));
    }
    // debugger;
    var cinema = JSON.parse(sessionStorage.getItem("cinema_data"));
    if (sessionStorage.getItem("selected_time") == null | sessionStorage.getItem("selected_time") == "undefined") {
        sessionStorage.setItem("selected_time", cinema[0]["date"]);
    }
    return cinema;
}

function print_movies_list()
{
    // debugger;
    const documentBody = document.body;
    const movieList = document.getElementById("movie-list");
    // debugger;
    var cinema = JSON.parse(sessionStorage.getItem("cinema_data"));
    const movieSelect = document.getElementById("movie-select");
    currentTime = movieSelect.value;
    // debugger;
    var currentMovieIndex = 0;
    var currentSessionIndex = 0
    // debugger;
    cinema.every(function(data) {
        if (data["date"] == currentTime) {
            data["movies"].forEach(movie => {
                movieBlock = document.createElement("div");
                movieBlock.className = "movie-block";

                movieTitleHref = document.createElement("a");
                movieTitleHref.id = `"title-${currentMovieIndex}"`;
                movieTitleHref.className = "movie-information-link";
                movieTitleHref.href = `movie-information.html?session_id=${currentSessionIndex}&movie_id=${currentMovieIndex}`;
                movieTitleHref.textContent = `${movie['title']}`;

                movieBlock.appendChild(movieTitleHref);

                movieImage = document.createElement("img");
                movieImage.className = "movie-img";
                movieImage.src = `http://localhost:1941${movie['image']}`;
                movieImage.alt = `${movie['title']} image`;

                movieInfo = document.createElement("div");
                movieInfo.className = "movie-info";
                movieInfo.appendChild(movieImage);

                movieInfoTextContent = document.createElement("div");
                movieInfoTextContent.className = "movie-info-text";
                if (movie['ageRating'] != "") {
                    movieInfoTextContent.innerHTML += `<b class="title-data">Возрастной рейтинг: </b>${movie['ageRating']}<br>`;
                }
                else {
                    movieInfoTextContent.innerHTML += `<b class="title-data">Возрастной рейтинг: </b>0+<br>`;
                }
                movie['countries'].forEach(country => {
                    movieInfoTextContent.innerHTML += `<b class="title-data">Страна(ы): </b>${country} `;
                })
                movieInfoTextContent.innerHTML += `<br><b class="title-data">Жанры: </b>`;
                movie['genres'].forEach(genre => {
                    movieInfoTextContent.innerHTML += `${genre} `;
                })
                movieInfoTextContent.innerHTML += `<br><b class="title-data">Год: </b>${movie['year']}<br>`;
                var timeIndex = 0;
                movie['shows'].forEach(show => {
                    var showTime = new Date(show["startsAtTimestamp"] * 1000)
                    // debugger;
                    showHours = showTime.getHours();
                    showHours = (Math.floor(showHours / 10) == 0)? `0${showHours}`: `${showHours}`
                    showMinutes = showTime.getMinutes();
                    showMinutes = (Math.floor(showMinutes / 10) == 0)? `0${showMinutes}`: `${showMinutes}`
                    movieInfoTextContent.innerHTML += `<a href="buy_ticket.html?session_id=${currentSessionIndex}&movie_id=${currentMovieIndex}&time_id=${timeIndex}" style="margin-right: 20px; color: rgb(255, 255, 255);">${showHours}:${showMinutes} (Зал №${show["hallIndex"]})</a>   `;
                    timeIndex++;
                })
                movieInfo.appendChild(movieInfoTextContent)
                movieBlock.appendChild(movieInfo);
                movieList.appendChild(movieBlock);
                // documentBody.innerHTML += "<br><br><br>";
                currentMovieIndex++;
            });
            return false;
        }
        currentMovieIndex = 0;
        currentSessionIndex++;
        return true;
    }); 
    // documentBody.appendChild(movieList);
}

document.addEventListener('DOMContentLoaded', () => {
    get_cinema_data();
    const cinema = JSON.parse(sessionStorage.getItem("cinema_data"));
    const movieSelect = document.getElementById("movie-select");
    cinema.forEach(data => {
        var currentDate = data["date"];
        var movieOption = document.createElement("option");
        movieOption.value = currentDate;
        movieOption.textContent = currentDate;
        movieSelect.appendChild(movieOption);
    });
    if (sessionStorage.getItem("selected_date") != null & sessionStorage.getItem("selected_date") != "undefined") {
        movieSelect.value = sessionStorage.getItem("selected_date");
    }
    movieSelect.addEventListener("change", on_movie_select);
    print_movies_list();
    const clearSessionButton = document.getElementById("clear-session-button");
    clearSessionButton.addEventListener("click", () => {
        sessionStorage.clear();
    })
})