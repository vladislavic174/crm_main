var tiketsCounter;
var placesStatus;

async function get_cinema_data()
{
    if (sessionStorage.getItem("cinema_data") == null | sessionStorage.getItem("cinema_data") == "undefined") {
        var cinema = await BackendAPI.getSchedule();
        sessionStorage.setItem("cinema_data", JSON.stringify(cinema));
    }
    // debugger;
    var cinema = JSON.parse(sessionStorage.getItem("cinema_data"));
    if (sessionStorage.getItem("selected_time") == null | sessionStorage.getItem("selected_time") == "undefined") {
        sessionStorage.setItem("selected_time", cinema[0]["date"]);
    }
    return cinema;
}

document.addEventListener('DOMContentLoaded', () => {
    const cinema = JSON.parse(sessionStorage.getItem("cinema_data"));
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    // debugger;
    const current_session_index = urlParams.get("session_id");
    const current_movie_index = urlParams.get("movie_id");
    const current_time_index = urlParams.get("time_id");
    const moviePageHref = document.getElementById("movie-page-href");
    moviePageHref.href = `movie-information.html?session_id=${current_session_index}&movie_id=${current_movie_index}`
    // debugger;
    const movie = cinema[current_session_index]["movies"][current_movie_index];
    // debugger;
    const movieTitle = document.getElementById("movie-title");
    movieTitle.innerHTML = movie["title"];
    const show = movie["shows"][current_time_index];
    var showTime = new Date(show["startsAtTimestamp"] * 1000);
    const movieTime = document.getElementById("movie-time");
    tiketsCounter = 0;
    // debugger;
    showHours = showTime.getHours();
    showHours = (Math.floor(showHours / 10) == 0)? `0${showHours}`: `${showHours}`
    showMinutes = showTime.getMinutes();
    showMinutes = (Math.floor(showMinutes / 10) == 0)? `0${showMinutes}`: `${showMinutes}`;
    movieTime.textContent = `${showHours}:${showMinutes} (Зал №${show["hallIndex"]})`;
    const hallPlaces = document.getElementsByClassName("hall-place");
    placesStatus = [];
    // placesStatus.push(current_session_index);
    // placesStatus.push(current_movie_index);
    // placesStatus.push(current_time_index);
    const places_status_key = `places_status_${show.id}`;
    if (sessionStorage.getItem(places_status_key) == null | sessionStorage.getItem(places_status_key) == "undefined") {
        for (var i = 0; i < hallPlaces.length; i++) {
            placesStatus.push(false);
        }
        sessionStorage.setItem(places_status_key, JSON.stringify(placesStatus));
    }
    placesStatus = JSON.parse(sessionStorage.getItem(places_status_key));
    debugger;
    for (var hallPlaceIndex = 0; hallPlaceIndex < hallPlaces.length; hallPlaceIndex++) {
        hallPlaces[hallPlaceIndex].id = `${hallPlaceIndex}`;
        hallPlaces[hallPlaceIndex].className = (placesStatus[hallPlaceIndex])? "hall-place busy": "hall-place";
        if (hallPlaces[hallPlaceIndex].className != "hall-place busy") {
            hallPlaces[hallPlaceIndex].addEventListener("click", (event) => {
                // debugger;
                const currentPlace = hallPlaces[event.currentTarget.id];
                currentPlace.className = (currentPlace.className == "hall-place selected")? "hall-place": "hall-place selected";
                tiketsCounter = (currentPlace.className == "hall-place selected")? (tiketsCounter + 1): (tiketsCounter - 1);
                placesStatus[event.currentTarget.id] = (currentPlace.className == "hall-place selected")? true: false;
                // debugger;
                const ticketsCounterInDocument = document.getElementById("tikets-counter");
                ticketsCounterInDocument.textContent = tiketsCounter;
            });
        }
    };
    buyTicketButton = document.getElementById("buy-ticket-button");
    buyTicketButton.addEventListener("click", () => {
        const places_status_key = `places_status_${show.id}`;
        sessionStorage.setItem(places_status_key, JSON.stringify(placesStatus));
        window.location.href = "index.html";
    })
})