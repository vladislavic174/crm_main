async function print_movies_list()
{
    // debugger;
    // debugger;
    const documentBody = document.body;
    if (sessionStorage.getItem("cinema_data") == null) {
        var cinema = await BackendAPI.getSchedule();
        sessionStorage.setItem("cinema_data", JSON.stringify(cinema));
    }
    var cinema = JSON.parse(sessionStorage.getItem("cinema_data"));
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    // debugger;
    const current_session_index = urlParams.get("session_id");
    const current_movie_index = urlParams.get("movie_id");
    const movie = cinema[current_session_index]["movies"][current_movie_index];
    // debugger;
    movieBlock = document.createElement("div");
    movieBlock.className = "movie-full-info-block";
    movieTitle = document.createElement("div");
    // movieTitle.onclick = function() {
    //     debugger;
    //     alert("test");
    // };
    movieTitle.id = `"movie-title"`;
    movieTitle.className = "movie-title-full";
    movieTitle.textContent = `${movie['title']}`;
    movieBlock.appendChild(movieTitle);
    movieImage = document.createElement("img");
    movieImage.className = "movie-img-full";
    movieImage.src = `http://localhost:1941${movie['image']}`;
    movieImage.alt = `${movie['title']} image`;
    // movieBlock.appendChild(movieImage);
    // movieBlock.innerHTML += `<br><img class="movie-img" src="http://localhost:1941${movie['image']}" alt="${movie['title']} image" />`;
    // movieBlock.innerHTML += "<br>";
    // movieBlock.innerHTML += `<a id="title-${currentIndex}" class="movie-information-link" href="movie-information.html">${movie['title']}</a><br>`;
    // debugger;
    movieInfo = document.createElement("div");
    movieInfo.className = "movie-info";
    movieInfo.appendChild(movieImage);
    movieInfoTextContent = document.createElement("div");
    movieInfoTextContent.className = "movie-info-text";
    movieInfoTextContent.innerHTML += '<b class="title-data">Возрастной рейтинг: </b>';
    if (movie['ageRating'] != "") {
        movieInfoTextContent.innerHTML += `${movie['ageRating']}<br>`;
    }
    else {
        movieInfoTextContent.innerHTML += "0+<br>";
    }
    movieInfoTextContent.innerHTML += '<b class="title-data">Страна(ы): </b>'
    movie['countries'].forEach(country => {
        movieInfoTextContent.innerHTML += `${country} `;
    })
    movieInfoTextContent.innerHTML += "<br>";
    movieInfoTextContent.innerHTML += '<b class="title-data">Жанры: </b>'
    movie['genres'].forEach(genre => {
        movieInfoTextContent.innerHTML += `${genre} `;
    })
    movieInfoTextContent.innerHTML += `<br><b class="title-data">Год: </b>${movie['year']}<br>`;
    var timeIndex = 0;
    movie['shows'].forEach(show => {
        var showTime = new Date(show["startsAtTimestamp"] * 1000)
        // debugger;
        showHours = showTime.getHours();
        showHours = (Math.floor(showHours / 10) == 0)? `0${showHours}`: `${showHours}`
        showMinutes = showTime.getMinutes();
        showMinutes = (Math.floor(showMinutes / 10) == 0)? `0${showMinutes}`: `${showMinutes}`
        movieInfoTextContent.innerHTML += `<a href="buy_ticket.html?session_id=${current_session_index}&movie_id=${current_movie_index}&time_id=${timeIndex}" style="margin-right: 20px; color: rgb(255, 255, 255);">${showHours}:${showMinutes} (Зал №${show["hallIndex"]})</a>   `;
        timeIndex++;
    })
    movieInfo.appendChild(movieInfoTextContent)
    movieBlock.appendChild(movieInfo);
    movieDescription = document.createElement("div");
    movieDescription.className = "movie-description";
    movieDescription.innerHTML = `<h2 class="title-data">Описание:</h2>${movie["description"]}`;
    movieBlock.appendChild(movieDescription);
    documentBody.appendChild(movieBlock);
    documentBody.appendChild(movieBlock);
}
print_movies_list();