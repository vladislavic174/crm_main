document.onload = function() {
    var movieTitleHref = document.getElementsByClassName(`"movie-information-link"`);
    console.log("7654321")
}

// document.addEventListener('DOMContentLoaded', () => {
//     // print_movies_list();
//     var movieTitleHref = document.getElementsByClassName(`"movie-information-link"`);
//     debugger;
// })